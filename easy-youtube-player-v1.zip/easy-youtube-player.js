/*
  Easy YouTube Player by Christian Heilmann
  Version: 1.0
  Homepage :http://icant.co.uk/sandbox/easy-youtube/
  Copyright (c) 2008, Christian Heilmann
  Code licensed under the BSD License:
  http://wait-till-i.com/license.txt
*/
var eYTp = function(){
  /************************************************************************  
    Configuration settings - change as needed 
  ************************************************************************/
  var config = {
    /*
      Your YouTube/Google Developer ID, available at 
      http://code.google.com/apis/youtube/dashboard/
    */
    devkey:'YOUR_DEVELOPER_KEY',
    /*
      Increase or decrease in volume, the volume reaches from 0 - 100 
    */
    volumeChange:10,
    /*
      seconds to repeat when the user hits the back button
    */
    secondsToRepeat:10,
    /*
      Dimensions of the movie
    */
    movieWidth:400,
    movieHeight:300,
    /*
      background colour of the movie player
    */
    playerbackground:'#cccccc',
    /*
      ID and class names of the created elements
    */
    css:{
      ids:{
        container:'easyyoutubeplayer',
        controls:'eytp-controls',
        player:'easyyoutubeplayer'
      },
      classes:{
        hover:'hover'
      }
    },
    /*
      Player buttons, changes in the order will be reflected in the 
      player. The IDs are needed for the CSS styling and the label 
      are the texts displayed above the button
    */
    buttons:{
      play: { id:'eytp-play', label:'Play' },
      repeat: { id:'eytp-repeat', label:'Back' },
      pause: { id:'eytp-pause', label:'Pause' },
      stop: { id:'eytp-stop', label:'Stop' },
      louder: { id:'eytp-louder', label:'Louder' },
      quieter : { id:'eytp-quieter', label:'Quieter' },
      mute:{ id:'eytp-mute', label:'No Sound' }
    }
  };
  /************************************************************************
    End configuration
  ************************************************************************/
  var ytplayer,id;
  var containerID = config.css.ids.container;
  var playercontainer = document.getElementById(containerID);
  if(playercontainer){
    var controls = document.createElement('ul');
    controls.id = config.css.ids.controls;
    playercontainer.parentNode.insertBefore(controls, playercontainer);
    var params = { 
      allowScriptAccess:'always', 
      bgcolor:config.playerbackground
    };
    var atts = {
      id:config.css.ids.player
    };
    swfobject.embedSWF('http://gdata.youtube.com/apiplayer?key=' + 
                        config.devkey + '&enablejsapi=1&playerapiid=' +
                        containerID, containerID, config.movieWidth, 
                        config.movieHeight, '8', null, null, params, atts);
    function onPlayerReady(playerID){
      ytplayer = document.getElementById(config.css.ids.player);
      addControls();
      var loc = window.location.href.toString();
      var urlid = loc.split('#')[0].match(/v=([^&|$]+)/);
      if(typeof urlid[1]==='string'){
        id = urlid[1];
        ytplayer.cueVideoById(id,0);
      }
    };
    var actions = {
      play:function(){
        var state = ytplayer.getPlayerState();
        if(state === -1){
          ytplayer.loadVideoById(id,0);
        } else {
          ytplayer.playVideo();
        };
      },
      pause:function(){
        ytplayer.pauseVideo();
      },
      stop:function(){
        ytplayer.stopVideo();
      },
      louder:function(){
        changeVolume(config.volumeChange);
      },
      quieter:function(){
        changeVolume(-config.volumeChange);
      },
      mute:function(){
        highlightPlay(this);
        ytplayer.mute();
      },
      repeat:function(){
        highlightPlay(this);
        var now = ytplayer.getCurrentTime();
        var s = config.secondsToRepeat;
        var then = (now - s) > 0 ? (now-s) : 0;
        ytplayer.seekTo(then,false);
      }
    };
    function changeVolume(change) {
      highlightPlay(this);
      ytplayer.unMute();          
      var current = ytplayer.getVolume();
      var newVolume = current + change;
      if(newVolume > 100) { newVolume = 100; };
      if(newVolume < 0) { newVolume = 0; };
      ytplayer.setVolume(newVolume);
    };
    function highlightPlay(o){
      o.className = '';
      var p = document.getElementById(config.buttons.play.id);
      eYTp.current = p;
      p.className = 'hover';
    };
    function addControls(){
      for(x in config.buttons){
        var obj = config.buttons[x];
        var li = document.createElement('li');
        var a = document.createElement('a');
        a.id = obj.id;
        a.innerHTML = obj.label;
        a.onclick = function(){
          if(eYTp.current){
            eYTp.current.className = '';
          };
          this.className = config.css.classes.hover;
          eYTp.current = this;
          actions[this.href.split('#')[1]]();
          return false;
        };
        a.onmouseover = function(){
          this.className = config.css.classes.hover;
        };
        a.onmouseout = function(){
          if(eYTp.current !== this){
            this.className ='';
          };
        };
        a.onfocus = function(){
          this.className = config.css.classes.hover;
        };
        a.onblur = function(){
          if(eYTp.current !== this){
            this.className ='';
          }
        };
        a.href = '#' + x;
        li.appendChild(a);
        controls.appendChild(li);
      };
    };
    return{
      ready:onPlayerReady
    };
  }; 
}();
function onYouTubePlayerReady(playerId) {
  eYTp.ready(playerId);
};